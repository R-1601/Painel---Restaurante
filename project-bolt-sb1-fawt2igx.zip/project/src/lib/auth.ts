import { useState, useEffect, useCallback } from 'react';
import { supabase } from './supabase';

export type ProfileStatus = 'pendente' | 'aprovado' | 'recusado';
export type ProfileRole = 'admin' | 'usuario';

export interface Profile {
  id: string;
  email: string;
  status: ProfileStatus;
  role: ProfileRole;
  created_at?: string;
  updated_at?: string;
}

export interface AuthState {
  loading: boolean;
  session: import('@supabase/supabase-js').Session | null;
  profile: Profile | null;
}

export function useAuth(): AuthState & {
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
} {
  const [state, setState] = useState<AuthState>({ loading: true, session: null, profile: null });

  const loadProfile = useCallback(async (uid: string): Promise<Profile | null> => {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, email, status, role, created_at, updated_at')
      .eq('id', uid)
      .maybeSingle();
    if (error) {
      console.error('Erro ao carregar perfil:', error);
      return null;
    }
    return (data as Profile) || null;
  }, []);

  const refreshProfile = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      setState((s) => ({ ...s, profile: null }));
      return;
    }
    const p = await loadProfile(user.id);
    setState((s) => ({ ...s, profile: p }));
  }, [loadProfile]);

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!mounted) return;
      if (!session) {
        setState({ loading: false, session: null, profile: null });
        return;
      }
      const p = await loadProfile(session.user.id);
      if (!mounted) return;
      setState({ loading: false, session, profile: p });
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      (async () => {
        if (!session) {
          setState({ loading: false, session: null, profile: null });
          return;
        }
        const p = await loadProfile(session.user.id);
        if (!mounted) return;
        setState({ loading: false, session, profile: p });
      })();
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setState({ loading: false, session: null, profile: null });
  }, []);

  return { ...state, signOut, refreshProfile };
}
