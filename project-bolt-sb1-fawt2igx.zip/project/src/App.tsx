import { useState, useEffect, useMemo } from 'react';
import { LayoutDashboard, Package, Wallet, Receipt, ShieldCheck, LogOut } from 'lucide-react';
import { supabase } from './lib/supabase';
import { useAuth } from './lib/auth';
import { type EstoqueItem, type CaixaItem, type ContaItem, type FormaPagamento, CANAIS_VENDA, currentMonthKey } from './types';
import ResumoTab from './components/ResumoTab';
import EstoqueTab from './components/EstoqueTab';
import CaixaTab from './components/CaixaTab';
import ContasTab from './components/ContasTab';
import AprovacoesTab from './components/AprovacoesTab';
import AuthScreen from './components/AuthScreen';
import { PendingScreen, RejectedScreen } from './components/WaitingScreen';

export default function App() {
  const { loading, session, profile, signOut } = useAuth();

  if (loading) {
    return (
      <div className="bg-paper min-h-screen flex items-center justify-center font-sans text-ink">
        Carregando...
      </div>
    );
  }

  if (!session || !profile) {
    return <AuthScreen />;
  }

  if (profile.status === 'pendente') {
    return <PendingScreen email={profile.email} />;
  }
  if (profile.status === 'recusado') {
    return <RejectedScreen email={profile.email} />;
  }

  return <Dashboard isAdmin={profile.role === 'admin'} email={profile.email} onSignOut={signOut} />;
}

function Dashboard({ isAdmin, email, onSignOut }: { isAdmin: boolean; email: string; onSignOut: () => Promise<void> }) {
  const [tab, setTab] = useState('resumo');
  const [loading, setLoading] = useState(true);
  const [estoque, setEstoque] = useState<EstoqueItem[]>([]);
  const [caixa, setCaixa] = useState<CaixaItem[]>([]);
  const [contas, setContas] = useState<ContaItem[]>([]);
  const [formasPagamento, setFormasPagamento] = useState<FormaPagamento[]>([]);

  const tabs = useMemo(() => {
    const base = [
      { id: 'resumo', label: 'Resumo', icon: LayoutDashboard },
      { id: 'estoque', label: 'Estoque', icon: Package },
      { id: 'caixa', label: 'Caixa', icon: Wallet },
      { id: 'contas', label: 'Contas a pagar', icon: Receipt },
    ];
    if (isAdmin) base.push({ id: 'aprovacoes', label: 'Aprovações', icon: ShieldCheck });
    return base;
  }, [isAdmin]);

  useEffect(() => {
    (async () => {
      const [e, c, ct, fp] = await Promise.all([
        supabase.from('estoque').select('*').order('created_at', { ascending: false }),
        supabase.from('caixa').select('*').order('created_at', { ascending: false }),
        supabase.from('contas').select('*').order('created_at', { ascending: false }),
        supabase.from('formas_pagamento').select('*').order('ordem', { ascending: true }),
      ]);

      if (e.error) console.error('Erro ao carregar estoque:', e.error);
      if (c.error) console.error('Erro ao carregar caixa:', c.error);
      if (ct.error) console.error('Erro ao carregar contas:', ct.error);
      if (fp.error) console.error('Erro ao carregar formas_pagamento:', fp.error);

      setEstoque((e.data || []) as EstoqueItem[]);
      setCaixa((c.data || []) as CaixaItem[]);
      setContas((ct.data || []) as ContaItem[]);
      setFormasPagamento((fp.data || []) as FormaPagamento[]);
      setLoading(false);
    })();
  }, []);

  const mesAtual = currentMonthKey();
  const mesAnteriorKey = useMemo(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    return d.toISOString().slice(0, 7);
  }, []);

  const caixaMes = useMemo(() => caixa.filter((c) => c.data?.startsWith(mesAtual)), [caixa, mesAtual]);
  const caixaMesAnterior = useMemo(() => caixa.filter((c) => c.data?.startsWith(mesAnteriorKey)), [caixa, mesAnteriorKey]);

  const entradasMes = useMemo(() => caixaMes.filter((c) => c.tipo === 'entrada'), [caixaMes]);
  const saidasMes = useMemo(() => caixaMes.filter((c) => c.tipo === 'saida'), [caixaMes]);

  const totalEntradasBruto = useMemo(() => entradasMes.reduce((s, c) => s + Number(c.valor), 0), [entradasMes]);
  const totalTaxas = useMemo(() => entradasMes.reduce((s, c) => s + (Number(c.valor) * Number(c.taxa || 0)) / 100, 0), [entradasMes]);
  const totalEntradasLiquido = totalEntradasBruto - totalTaxas;
  const totalSaidas = useMemo(() => saidasMes.reduce((s, c) => s + Number(c.valor), 0), [saidasMes]);
  const saldo = totalEntradasLiquido - totalSaidas;

  const saldoMesAnterior = useMemo(() => {
    const ent = caixaMesAnterior.filter((c) => c.tipo === 'entrada');
    const sai = caixaMesAnterior.filter((c) => c.tipo === 'saida');
    const bruto = ent.reduce((s, c) => s + Number(c.valor), 0);
    const taxas = ent.reduce((s, c) => s + (Number(c.valor) * Number(c.taxa || 0)) / 100, 0);
    const saidasT = sai.reduce((s, c) => s + Number(c.valor), 0);
    return bruto - taxas - saidasT;
  }, [caixaMesAnterior]);

  const ticketMedio = entradasMes.length ? totalEntradasBruto / entradasMes.length : 0;

  const porCanal = useMemo(() => {
    const map: Record<string, number> = {};
    CANAIS_VENDA.forEach((c) => (map[c.id] = 0));
    entradasMes.forEach((e) => { if (e.canal) map[e.canal] = (map[e.canal] || 0) + Number(e.valor); });
    return map;
  }, [entradasMes]);

  const contasPendentes = useMemo(() => contas.filter((c) => c.status !== 'pago'), [contas]);
  const totalContasPendentes = useMemo(() => contasPendentes.reduce((s, c) => s + Number(c.valor), 0), [contasPendentes]);
  const estoqueBaixo = useMemo(() => estoque.filter((i) => Number(i.qtd) <= Number(i.minimo)), [estoque]);

  if (loading) {
    return (
      <div className="bg-paper min-h-screen flex items-center justify-center font-sans text-ink">
        Carregando painel...
      </div>
    );
  }

  return (
    <div className="bg-paper min-h-screen text-ink font-sans">
      <div className="flex min-h-screen">
        <div className="w-[220px] bg-green text-[#F2EFE4] py-7 shrink-0 flex flex-col">
          <div className="px-6 pb-6 border-b border-white/10 mb-3">
            <div className="font-serif text-[22px] font-bold leading-[1.15]">Painel do<br />Restaurante</div>
            <div className="text-[11.5px] text-sidebar-text mt-2 truncate">{email}</div>
          </div>
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2.5 w-full py-3.5 px-6 ${active ? 'bg-paper text-green-dark rounded-l-lg' : 'text-sidebar-text hover:text-sidebar-active'} border-none cursor-pointer text-[14.5px] font-semibold text-left transition-colors`}
              >
                <Icon size={17} strokeWidth={2} />
                {t.label}
              </button>
            );
          })}
          <div className="mt-auto px-6 pt-6">
            <button
              onClick={onSignOut}
              className="flex items-center gap-2 text-[13px] font-semibold text-sidebar-text hover:text-sidebar-active bg-transparent border-none cursor-pointer transition-colors"
            >
              <LogOut size={16} /> Sair
            </button>
          </div>
        </div>

        <div className="flex-1 p-8 px-10 max-w-[1100px]">
          {tab === 'resumo' && (
            <ResumoTab
              totalEntradasBruto={totalEntradasBruto}
              totalTaxas={totalTaxas}
              totalEntradasLiquido={totalEntradasLiquido}
              totalSaidas={totalSaidas}
              saldo={saldo}
              saldoMesAnterior={saldoMesAnterior}
              ticketMedio={ticketMedio}
              porCanal={porCanal}
              totalContasPendentes={totalContasPendentes}
              contasPendentes={contasPendentes}
              estoqueBaixo={estoqueBaixo}
            />
          )}
          {tab === 'estoque' && <EstoqueTab estoque={estoque} setEstoque={setEstoque} />}
          {tab === 'caixa' && (
            <CaixaTab
              caixa={caixa}
              setCaixa={setCaixa}
              formasPagamento={formasPagamento}
              setFormasPagamento={setFormasPagamento}
            />
          )}
          {tab === 'contas' && <ContasTab contas={contas} setContas={setContas} />}
          {tab === 'aprovacoes' && isAdmin && <AprovacoesTab />}
        </div>
      </div>
    </div>
  );
}
