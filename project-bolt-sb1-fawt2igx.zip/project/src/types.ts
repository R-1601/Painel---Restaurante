export interface EstoqueItem {
  id: string;
  nome: string;
  qtd: number;
  unidade: string;
  minimo: number;
}

export interface CaixaItem {
  id: string;
  data: string;
  descricao: string;
  valor: number;
  tipo: 'entrada' | 'saida';
  canal?: string;
  forma_pagamento?: string;
  taxa?: number;
  categoria?: string;
}

export interface ContaItem {
  id: string;
  nome: string;
  categoria: string;
  valor: number;
  vencimento: string;
  status: 'pendente' | 'pago';
}

export interface FormaPagamento {
  id: string;
  label: string;
  taxa: number;
  ordem: number;
}

export const CATEGORIAS_CONTA = [
  { id: 'agua', label: 'Água' },
  { id: 'luz', label: 'Luz' },
  { id: 'fornecedor', label: 'Fornecedor' },
  { id: 'aluguel', label: 'Aluguel' },
  { id: 'outro', label: 'Outro' },
];

export const CANAIS_VENDA = [
  { id: 'delivery', label: 'Delivery' },
  { id: 'balcao', label: 'Balcão' },
  { id: 'retirada', label: 'Retirada' },
];

export const CATEGORIAS_DESPESA = [
  { id: 'ingredientes', label: 'Ingredientes' },
  { id: 'embalagem', label: 'Embalagem' },
  { id: 'funcionario', label: 'Funcionário' },
  { id: 'manutencao', label: 'Manutenção' },
  { id: 'taxas_app', label: 'Taxa de app/plataforma' },
  { id: 'outro', label: 'Outro' },
];

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function currentMonthKey() {
  return new Date().toISOString().slice(0, 7);
}

export function formatBRL(v: number) {
  return (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function formatDatePt(iso: string) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}
