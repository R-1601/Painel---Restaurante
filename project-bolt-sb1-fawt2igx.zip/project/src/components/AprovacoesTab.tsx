import { useEffect, useState, useCallback } from 'react';
import { Check, X, Clock, RefreshCw } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { type Profile } from '../lib/auth';
import { SectionTitle, EmptyState } from './ui';

type Row = Profile & { created_at?: string };

function formatDate(iso?: string) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function AprovacoesTab() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const { data, error: err } = await supabase
      .from('profiles')
      .select('id, email, status, role, created_at, updated_at')
      .order('created_at', { ascending: false });
    if (err) {
      setError(err.message);
    } else {
      setRows((data || []) as Row[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const setStatus = async (p: Row, status: 'aprovado' | 'recusado') => {
    setBusyId(p.id);
    const { error: err } = await supabase
      .from('profiles')
      .update({ status })
      .eq('id', p.id);
    setBusyId(null);
    if (err) {
      setError(err.message);
      return;
    }
    setRows((r) => r.map((x) => (x.id === p.id ? { ...x, status } : x)));
  };

  const pendentes = rows.filter((r) => r.status === 'pendente');
  const aprovados = rows.filter((r) => r.status === 'aprovado');
  const recusados = rows.filter((r) => r.status === 'recusado');

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <SectionTitle subtitle="Aprove ou recuse novos cadastros de usuários">Aprovações</SectionTitle>
        <button
          onClick={load}
          className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#5A5344] hover:text-green-dark bg-white border border-card-border px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
        >
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Atualizar
        </button>
      </div>

      {error && <div className="text-[12.5px] text-red bg-red-bg px-3 py-2 rounded-md mb-4">{error}</div>}

      <div className="mb-6">
        <h3 className="font-serif text-[17px] font-bold text-green-dark mb-3 flex items-center gap-2">
          <Clock size={16} className="text-gold" /> Pendentes
          <span className="text-[12px] font-sans font-semibold text-[#8A8270]">({pendentes.length})</span>
        </h3>
        {pendentes.length === 0 ? (
          <EmptyState text="Nenhum cadastro pendente." />
        ) : (
          <div className="bg-white rounded-xl border border-card-border overflow-hidden">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="text-left px-4 py-2.5 text-xs text-[#8A8270] uppercase tracking-wide border-b border-paper-line">E-mail</th>
                  <th className="text-left px-4 py-2.5 text-xs text-[#8A8270] uppercase tracking-wide border-b border-paper-line">Cadastrado em</th>
                  <th className="text-right px-4 py-2.5 text-xs text-[#8A8270] uppercase tracking-wide border-b border-paper-line">Ações</th>
                </tr>
              </thead>
              <tbody>
                {pendentes.map((p) => (
                  <tr key={p.id}>
                    <td className="px-4 py-3 text-sm border-b border-paper-line">{p.email}</td>
                    <td className="px-4 py-3 text-sm text-[#6B6355] border-b border-paper-line">{formatDate(p.created_at)}</td>
                    <td className="px-4 py-3 text-right border-b border-paper-line">
                      <div className="inline-flex gap-2">
                        <button
                          disabled={busyId === p.id}
                          onClick={() => setStatus(p, 'aprovado')}
                          className="inline-flex items-center gap-1.5 bg-green text-[#F2EFE4] border-none px-3 py-1.5 rounded-md text-[12.5px] font-semibold cursor-pointer hover:bg-green-dark transition-colors disabled:opacity-60"
                        >
                          <Check size={14} /> Aprovar
                        </button>
                        <button
                          disabled={busyId === p.id}
                          onClick={() => setStatus(p, 'recusado')}
                          className="inline-flex items-center gap-1.5 bg-white text-red border border-red/40 px-3 py-1.5 rounded-md text-[12.5px] font-semibold cursor-pointer hover:bg-red-bg transition-colors disabled:opacity-60"
                        >
                          <X size={14} /> Recusar
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <div>
          <h3 className="font-serif text-[15px] font-bold text-green-dark mb-3 flex items-center gap-2">
            <Check size={15} className="text-teal" /> Aprovados
            <span className="text-[12px] font-sans font-semibold text-[#8A8270]">({aprovados.length})</span>
          </h3>
          {aprovados.length === 0 ? (
            <EmptyState text="Nenhum usuário aprovado." />
          ) : (
            <div className="bg-white rounded-xl border border-card-border divide-y divide-paper-line">
              {aprovados.map((p) => (
                <div key={p.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                  <span>{p.email}{p.role === 'admin' && <span className="ml-2 text-[10.5px] font-bold uppercase text-gold bg-gold/10 px-1.5 py-0.5 rounded">admin</span>}</span>
                  <button
                    disabled={busyId === p.id || p.role === 'admin'}
                    onClick={() => setStatus(p, 'recusado')}
                    className="text-[12px] font-semibold text-[#8A8270] hover:text-red bg-transparent border-none cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    Revogar
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
        <div>
          <h3 className="font-serif text-[15px] font-bold text-green-dark mb-3 flex items-center gap-2">
            <X size={15} className="text-red" /> Recusados
            <span className="text-[12px] font-sans font-semibold text-[#8A8270]">({recusados.length})</span>
          </h3>
          {recusados.length === 0 ? (
            <EmptyState text="Nenhum cadastro recusado." />
          ) : (
            <div className="bg-white rounded-xl border border-card-border divide-y divide-paper-line">
              {recusados.map((p) => (
                <div key={p.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                  <span className="text-[#6B6355]">{p.email}</span>
                  <button
                    disabled={busyId === p.id}
                    onClick={() => setStatus(p, 'aprovado')}
                    className="text-[12px] font-semibold text-teal hover:text-green-dark bg-transparent border-none cursor-pointer"
                  >
                    Reativar
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
