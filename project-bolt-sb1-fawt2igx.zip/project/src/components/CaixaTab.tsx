import { useState } from 'react';
import { Trash2, Settings } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { type CaixaItem, type FormaPagamento, CANAIS_VENDA, CATEGORIAS_DESPESA, todayISO, formatBRL, formatDatePt } from '../types';
import { SectionTitle, EmptyState, IconBtn, PrimaryBtn, GhostBtn, Modal, FieldLabel, Th, Td, inputClass } from './ui';

interface CaixaTabProps {
  caixa: CaixaItem[];
  setCaixa: (next: CaixaItem[]) => void;
  formasPagamento: FormaPagamento[];
  setFormasPagamento: (next: FormaPagamento[]) => void;
}

export default function CaixaTab({ caixa, setCaixa, formasPagamento, setFormasPagamento }: CaixaTabProps) {
  const [open, setOpen] = useState(false);
  const [openTaxas, setOpenTaxas] = useState(false);
  const [form, setForm] = useState({
    data: todayISO(), descricao: '', valor: '', tipo: 'entrada',
    canal: 'delivery', forma_pagamento: 'dinheiro', categoria: 'ingredientes',
  });

  const ordenado = [...caixa].sort((a, b) => (a.data < b.data ? 1 : -1));

  const addEntrada = async () => {
    if (!form.descricao || form.valor === '') return;
    const taxa = form.tipo === 'entrada' ? Number(formasPagamento.find((f) => f.id === form.forma_pagamento)?.taxa || 0) : 0;
    const novo = {
      data: form.data,
      descricao: form.descricao,
      valor: Number(form.valor),
      tipo: form.tipo,
      ...(form.tipo === 'entrada'
        ? { canal: form.canal, forma_pagamento: form.forma_pagamento, taxa }
        : { categoria: form.categoria, taxa: 0 }),
    };
    const { data, error } = await supabase.from('caixa').insert(novo).select().single();
    if (error) { console.error('Erro ao inserir caixa:', error); return; }
    setCaixa([...caixa, data]);
    setForm({ ...form, descricao: '', valor: '' });
    setOpen(false);
  };

  const removeEntrada = async (id: string) => {
    const { error } = await supabase.from('caixa').delete().eq('id', id);
    if (error) { console.error('Erro ao remover caixa:', error); return; }
    setCaixa(caixa.filter((c) => c.id !== id));
  };

  const updateTaxa = async (id: string, novaTaxa: number) => {
    const { error } = await supabase.from('formas_pagamento').update({ taxa: novaTaxa }).eq('id', id);
    if (error) { console.error('Erro ao atualizar taxa:', error); return; }
    setFormasPagamento(formasPagamento.map((f) => (f.id === id ? { ...f, taxa: novaTaxa } : f)));
  };

  return (
    <div>
      <div className="flex justify-between items-end">
        <SectionTitle subtitle="Lançamentos de vendas e despesas do dia a dia.">Caixa</SectionTitle>
        <div className="flex gap-2.5">
          <GhostBtn onClick={() => setOpenTaxas(true)}><Settings size={15} /> Taxas</GhostBtn>
          <PrimaryBtn onClick={() => setOpen(true)}>Novo lançamento</PrimaryBtn>
        </div>
      </div>

      <div className="bg-white border border-card-border rounded-lg overflow-hidden">
        {ordenado.length === 0 ? <EmptyState text="Nenhum lançamento ainda." /> : (
          <table className="w-full border-collapse">
            <thead>
              <tr><Th>Data</Th><Th>Descrição</Th><Th>Canal / Categoria</Th><Th>Forma pgto</Th><Th>Valor líquido</Th><Th></Th></tr>
            </thead>
            <tbody>
              {ordenado.map((c) => {
                const liquido = c.tipo === 'entrada' ? c.valor * (1 - (c.taxa || 0) / 100) : c.valor;
                return (
                  <tr key={c.id}>
                    <Td className="font-mono text-[#8A8270]">{formatDatePt(c.data)}</Td>
                    <Td>{c.descricao}</Td>
                    <Td>
                      <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full"
                        style={{
                          background: c.tipo === 'entrada' ? '#E7F0EC' : '#F6E7E5',
                          color: c.tipo === 'entrada' ? '#2F6F62' : '#B33A3A',
                        }}>
                        {c.tipo === 'entrada' ? CANAIS_VENDA.find((k) => k.id === c.canal)?.label : CATEGORIAS_DESPESA.find((k) => k.id === c.categoria)?.label}
                      </span>
                    </Td>
                    <Td className="text-[#8A8270] text-[13px]">
                      {c.tipo === 'entrada' ? `${formasPagamento.find((f) => f.id === c.forma_pagamento)?.label} (${c.taxa || 0}%)` : '—'}
                    </Td>
                    <Td className="font-mono font-semibold" style={{ color: c.tipo === 'entrada' ? '#2F6F62' : '#B33A3A' }}>
                      {c.tipo === 'entrada' ? '+' : '−'} {formatBRL(liquido)}
                    </Td>
                    <Td><IconBtn onClick={() => removeEntrada(c.id)} color="#B33A3A"><Trash2 size={16} /></IconBtn></Td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {open && (
        <Modal title="Novo lançamento" onClose={() => setOpen(false)}>
          <FieldLabel>Tipo</FieldLabel>
          <div className="flex gap-2">
            {['entrada', 'saida'].map((t) => (
              <button key={t} onClick={() => setForm({ ...form, tipo: t })}
                className="flex-1 py-2 rounded-md cursor-pointer font-semibold text-[13.5px] transition-colors"
                style={{
                  border: `1px solid ${form.tipo === t ? '#163A2E' : '#DAD2BC'}`,
                  background: form.tipo === t ? '#163A2E' : '#FCFAF4',
                  color: form.tipo === t ? '#F2EFE4' : '#20291F',
                }}>
                {t === 'entrada' ? 'Entrada' : 'Saída'}
              </button>
            ))}
          </div>

          <FieldLabel>Data</FieldLabel>
          <input className={inputClass} type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} />

          <FieldLabel>Descrição</FieldLabel>
          <input className={inputClass} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })}
            placeholder={form.tipo === 'entrada' ? 'Ex: Venda combo executivo' : 'Ex: Compra de carnes'} />

          {form.tipo === 'entrada' ? (
            <>
              <FieldLabel>Canal de venda</FieldLabel>
              <select className={inputClass} value={form.canal} onChange={(e) => setForm({ ...form, canal: e.target.value })}>
                {CANAIS_VENDA.map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
              </select>
              <FieldLabel>Forma de pagamento</FieldLabel>
              <select className={inputClass} value={form.forma_pagamento} onChange={(e) => setForm({ ...form, forma_pagamento: e.target.value })}>
                {formasPagamento.map((k) => <option key={k.id} value={k.id}>{k.label} ({k.taxa}%)</option>)}
              </select>
            </>
          ) : (
            <>
              <FieldLabel>Categoria da despesa</FieldLabel>
              <select className={inputClass} value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}>
                {CATEGORIAS_DESPESA.map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
              </select>
            </>
          )}

          <FieldLabel>Valor bruto (R$)</FieldLabel>
          <input className={inputClass} type="number" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} />

          <div className="mt-5"><PrimaryBtn onClick={addEntrada}>Salvar lançamento</PrimaryBtn></div>
        </Modal>
      )}

      {openTaxas && (
        <Modal title="Taxas por forma de pagamento" onClose={() => setOpenTaxas(false)}>
          <p className="text-[13px] text-[#8A8270] mt-0">Ajuste o % que cada forma de pagamento desconta (maquininha, iFood, etc).</p>
          {formasPagamento.map((f) => (
            <div key={f.id} className="flex items-center justify-between mb-2.5">
              <span className="text-sm">{f.label}</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  className="w-[70px] px-2 py-1.5 rounded-md border border-card-border text-sm bg-[#FCFAF4] focus:outline-none focus:border-green focus:ring-1 focus:ring-green"
                  value={f.taxa}
                  onChange={(e) => updateTaxa(f.id, Number(e.target.value))}
                />
                <span className="text-[13px] text-[#8A8270]">%</span>
              </div>
            </div>
          ))}
        </Modal>
      )}
    </div>
  );
}
