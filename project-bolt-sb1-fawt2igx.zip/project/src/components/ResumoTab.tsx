import { Clock, AlertTriangle } from 'lucide-react';
import { formatBRL, formatDatePt, CANAIS_VENDA, type ContaItem, type EstoqueItem } from '../types';

interface ResumoTabProps {
  totalEntradasBruto: number;
  totalTaxas: number;
  totalEntradasLiquido: number;
  totalSaidas: number;
  saldo: number;
  saldoMesAnterior: number;
  ticketMedio: number;
  porCanal: Record<string, number>;
  totalContasPendentes: number;
  contasPendentes: ContaItem[];
  estoqueBaixo: EstoqueItem[];
}

function Row({ label, value, bold, color }: { label: string; value: string; bold?: boolean; color?: string }) {
  return (
    <div className={`flex justify-between text-sm py-1 ${bold ? 'font-bold' : 'font-normal'}`}>
      <span className="text-[#5A5344]">{label}</span>
      <span style={{ color: color || '#20291F' }}>{value}</span>
    </div>
  );
}

function AlertCard({ title, items, empty, icon: Icon, color }: { title: string; items: string[]; empty: string; icon: typeof Clock; color: string }) {
  return (
    <div className="bg-white border border-card-border rounded-lg p-5">
      <div className="flex items-center gap-2 mb-3.5">
        <Icon size={17} style={{ color }} />
        <span className="font-semibold text-[15px]">{title}</span>
      </div>
      {items.length === 0 ? (
        <p className="text-[13.5px] text-[#8A8270] m-0">{empty}</p>
      ) : (
        <ul className="m-0 pl-4 text-[13.5px] text-[#4A4536] leading-[1.9] list-disc">
          {items.map((it, i) => <li key={i}>{it}</li>)}
        </ul>
      )}
    </div>
  );
}

export default function ResumoTab({
  totalEntradasBruto, totalTaxas, totalEntradasLiquido, totalSaidas, saldo, saldoMesAnterior,
  ticketMedio, porCanal, totalContasPendentes, contasPendentes, estoqueBaixo,
}: ResumoTabProps) {
  const hoje = new Date();
  const mesNome = hoje.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  const diffMesAnterior = saldo - saldoMesAnterior;

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-[28px] font-bold text-green-dark leading-tight m-0">Resumo do mês</h1>
        <p className="text-[14px] text-[#6B6355] mt-1">Referente a {mesNome}</p>
      </div>

      <div className="flex gap-6 flex-wrap mb-7">
        <div className="bg-white border border-dashed border-card-border rounded p-7 px-8 w-[340px] font-mono shadow-sm">
          <div className="text-center text-xs tracking-widest text-[#8A8270] mb-4 uppercase">— Fechamento do mês —</div>
          <Row label="Vendas (bruto)" value={formatBRL(totalEntradasBruto)} color="#2F6F62" />
          <Row label="Taxas de pagamento" value={`− ${formatBRL(totalTaxas)}`} color="#C9A227" />
          <Row label="Vendas (líquido)" value={formatBRL(totalEntradasLiquido)} color="#2F6F62" bold />
          <Row label="Despesas" value={`− ${formatBRL(totalSaidas)}`} color="#B33A3A" />
          <div className="border-t border-dashed border-card-border my-3" />
          <Row label="Saldo" value={formatBRL(saldo)} bold color={saldo >= 0 ? '#2F6F62' : '#B33A3A'} />
          <div className="border-t border-dashed border-card-border my-3" />
          <Row label="Vs. mês passado" value={`${diffMesAnterior >= 0 ? '+' : ''}${formatBRL(diffMesAnterior)}`} color={diffMesAnterior >= 0 ? '#2F6F62' : '#B33A3A'} />
          <Row label="Ticket médio" value={formatBRL(ticketMedio)} />
          <Row label="Contas pendentes" value={formatBRL(totalContasPendentes)} color="#C9A227" />
        </div>

        <div className="bg-white border border-card-border rounded-lg p-5 min-w-[260px] flex-1">
          <div className="font-semibold text-[15px] mb-3.5">Vendas por canal</div>
          {CANAIS_VENDA.map((c) => {
            const valor = porCanal[c.id] || 0;
            const pct = totalEntradasBruto > 0 ? Math.round((valor / totalEntradasBruto) * 100) : 0;
            return (
              <div key={c.id} className="mb-3">
                <div className="flex justify-between text-[13.5px] mb-1">
                  <span className="text-[#5A5344]">{c.label}</span>
                  <span className="font-mono">{formatBRL(valor)} ({pct}%)</span>
                </div>
                <div className="bg-paper-line h-1.5 rounded-full overflow-hidden">
                  <div className="bg-green h-1.5 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <AlertCard
          title="Contas a vencer"
          empty="Nenhuma conta pendente. Tudo em dia!"
          items={contasPendentes.slice(0, 5).map((c) => `${c.nome} — ${formatBRL(c.valor)} (${formatDatePt(c.vencimento)})`)}
          icon={Clock}
          color="#C9A227"
        />
        <AlertCard
          title="Estoque baixo"
          empty="Nenhum item abaixo do mínimo."
          items={estoqueBaixo.slice(0, 5).map((i) => `${i.nome} — ${i.qtd} ${i.unidade} (mín. ${i.minimo})`)}
          icon={AlertTriangle}
          color="#B33A3A"
        />
      </div>
    </div>
  );
}
