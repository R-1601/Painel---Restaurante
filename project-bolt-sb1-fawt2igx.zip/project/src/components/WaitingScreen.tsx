import { Clock, XCircle, LogOut } from 'lucide-react';
import { supabase } from '../lib/supabase';

export function PendingScreen({ email }: { email: string }) {
  return (
    <Shell email={email}>
      <div className="w-14 h-14 rounded-full bg-teal-bg flex items-center justify-center mx-auto mb-4">
        <Clock size={26} className="text-teal" />
      </div>
      <h2 className="font-serif text-[22px] font-bold text-green-dark m-0 mb-2">Aguardando aprovação</h2>
      <p className="text-[14px] text-[#5A5344] leading-relaxed max-w-[360px]">
        Sua conta foi criada, mas ainda está pendente. Um administrador precisa
        aprovar seu acesso antes de você entrar no painel.
      </p>
    </Shell>
  );
}

export function RejectedScreen({ email }: { email: string }) {
  return (
    <Shell email={email}>
      <div className="w-14 h-14 rounded-full bg-red-bg flex items-center justify-center mx-auto mb-4">
        <XCircle size={26} className="text-red" />
      </div>
      <h2 className="font-serif text-[22px] font-bold text-green-dark m-0 mb-2">Cadastro recusado</h2>
      <p className="text-[14px] text-[#5A5344] leading-relaxed max-w-[360px]">
        Seu cadastro foi recusado pelo administrador. Entre em contato com a
        administração do restaurante para mais informações.
      </p>
    </Shell>
  );
}

function Shell({ email, children }: { email: string; children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-paper flex items-center justify-center font-sans text-ink px-4">
      <div className="w-full max-w-[420px] text-center">
        <div className="font-serif text-[24px] font-bold text-green-dark mb-6">Painel do Restaurante</div>
        <div className="bg-white rounded-xl border border-card-border p-8 shadow-sm">
          {children}
          <div className="mt-5 pt-4 border-t border-paper-line text-[12px] text-[#8A8270]">
            Conta: {email}
          </div>
          <button
            onClick={() => supabase.auth.signOut()}
            className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#5A5344] hover:text-green-dark bg-transparent border border-card-border px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
          >
            <LogOut size={15} /> Sair
          </button>
        </div>
      </div>
    </div>
  );
}
