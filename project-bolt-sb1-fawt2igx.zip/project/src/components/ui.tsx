import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';

export function SectionTitle({ children, subtitle }: { children: React.ReactNode; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="font-serif text-[28px] font-bold text-green-dark leading-tight m-0">{children}</h1>
      {subtitle && <p className="text-[14px] text-[#6B6355] mt-1">{subtitle}</p>}
    </div>
  );
}

export function EmptyState({ text }: { text: string }) {
  return <div className="py-8 text-center text-[#9A9280] text-sm">{text}</div>;
}

export function IconBtn({ onClick, color, children }: { onClick: () => void; color?: string; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className="bg-transparent border-none cursor-pointer p-1.5 flex" style={{ color: color || '#9A9280' }}>
      {children}
    </button>
  );
}

export function PrimaryBtn({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 bg-green text-[#F2EFE4] border-none px-4 py-2.5 rounded-lg text-sm font-semibold cursor-pointer hover:bg-green-dark transition-colors"
    >
      <Plus size={16} /> {children}
    </button>
  );
}

export function GhostBtn({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 bg-white text-ink border border-card-border px-3.5 py-2.5 rounded-lg text-sm font-semibold cursor-pointer hover:bg-paper transition-colors"
    >
      {children}
    </button>
  );
}

export function Th({ children }: { children?: React.ReactNode }) {
  return (
    <th className="text-left px-3 py-2.5 text-xs text-[#8A8270] uppercase tracking-wide border-b border-paper-line">
      {children}
    </th>
  );
}

export function Td({ children, className = '', style }: { children?: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return <td className={`px-3 py-3 text-sm border-b border-paper-line ${className}`} style={style}>{children}</td>;
}

export function Modal({ title, onClose, children, width = 380 }: { title: string; onClose: () => void; children: React.ReactNode; width?: number }) {
  return (
    <div className="fixed inset-0 bg-[rgba(20,30,25,0.4)] flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 overflow-y-auto shadow-2xl" style={{ width, maxHeight: '85vh' }}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="m-0 font-serif text-[19px] text-green-dark">{title}</h3>
          <button onClick={onClose} className="bg-transparent border-none cursor-pointer text-[#8A8270]">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="block text-[12.5px] font-semibold text-[#5A5344] mb-1.5 mt-3">{children}</label>;
}

export const inputClass =
  'w-full px-3 py-2 rounded-md border border-card-border text-sm bg-[#FCFAF4] focus:outline-none focus:border-green focus:ring-1 focus:ring-green transition-colors';

export function useModal() {
  const [open, setOpen] = useState(false);
  return { open, setOpen };
}
