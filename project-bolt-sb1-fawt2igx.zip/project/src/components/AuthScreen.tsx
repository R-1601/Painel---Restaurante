import { useState } from 'react';
import { supabase } from '../lib/supabase';

export default function AuthScreen() {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);
    if (!email.trim() || !password) {
      setError('Preencha e-mail e senha.');
      return;
    }
    if (password.length < 6) {
      setError('A senha deve ter ao menos 6 caracteres.');
      return;
    }
    setLoading(true);
    try {
      if (mode === 'signup') {
        const { error: err } = await supabase.auth.signUp({ email: email.trim(), password });
        if (err) throw err;
        setInfo('Cadastro criado! Sua conta está pendente de aprovação do administrador.');
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-paper flex items-center justify-center font-sans text-ink px-4">
      <div className="w-full max-w-[400px]">
        <div className="text-center mb-8">
          <div className="font-serif text-[30px] font-bold text-green-dark leading-tight">Painel do Restaurante</div>
          <p className="text-[13px] text-[#6B6355] mt-1">Gestão de estoque, caixa e contas</p>
        </div>

        <div className="bg-white rounded-xl border border-card-border p-6 shadow-sm">
          <div className="flex gap-1 mb-5 bg-paper rounded-lg p-1">
            <button
              onClick={() => { setMode('login'); setError(null); setInfo(null); }}
              className={`flex-1 py-2 rounded-md text-sm font-semibold border-none cursor-pointer transition-colors ${mode === 'login' ? 'bg-white text-green-dark shadow-sm' : 'bg-transparent text-[#6B6355]'}`}
            >
              Entrar
            </button>
            <button
              onClick={() => { setMode('signup'); setError(null); setInfo(null); }}
              className={`flex-1 py-2 rounded-md text-sm font-semibold border-none cursor-pointer transition-colors ${mode === 'signup' ? 'bg-white text-green-dark shadow-sm' : 'bg-transparent text-[#6B6355]'}`}
            >
              Cadastrar
            </button>
          </div>

          <form onSubmit={submit} className="space-y-3">
            <div>
              <label className="block text-[12.5px] font-semibold text-[#5A5344] mb-1.5">E-mail</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@exemplo.com"
                className="w-full px-3 py-2 rounded-md border border-card-border text-sm bg-[#FCFAF4] focus:outline-none focus:border-green focus:ring-1 focus:ring-green transition-colors"
                autoComplete="email"
              />
            </div>
            <div>
              <label className="block text-[12.5px] font-semibold text-[#5A5344] mb-1.5">Senha</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="mínimo 6 caracteres"
                className="w-full px-3 py-2 rounded-md border border-card-border text-sm bg-[#FCFAF4] focus:outline-none focus:border-green focus:ring-1 focus:ring-green transition-colors"
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              />
            </div>

            {error && <div className="text-[12.5px] text-red bg-red-bg px-3 py-2 rounded-md">{error}</div>}
            {info && <div className="text-[12.5px] text-teal bg-teal-bg px-3 py-2 rounded-md">{info}</div>}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-green text-[#F2EFE4] border-none px-4 py-2.5 rounded-lg text-sm font-semibold cursor-pointer hover:bg-green-dark transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? 'Aguarde...' : mode === 'login' ? 'Entrar' : 'Criar cadastro'}
            </button>
          </form>

          {mode === 'signup' && (
            <p className="text-[11.5px] text-[#8A8270] mt-4 leading-relaxed">
              Ao se cadastrar, sua conta fica com status <b>pendente</b>. Um administrador
              precisa aprovar antes de você conseguir entrar.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
