import { useState } from 'react';
import { Trash2, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { type EstoqueItem } from '../types';
import { SectionTitle, EmptyState, IconBtn, PrimaryBtn, Modal, FieldLabel, Th, Td, inputClass } from './ui';

interface EstoqueTabProps {
  estoque: EstoqueItem[];
  setEstoque: (next: EstoqueItem[]) => void;
}

export default function EstoqueTab({ estoque, setEstoque }: EstoqueTabProps) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ nome: '', qtd: '', unidade: 'un', minimo: '' });

  const addItem = async () => {
    if (!form.nome || form.qtd === '') return;
    const novo = { nome: form.nome, qtd: Number(form.qtd), unidade: form.unidade, minimo: Number(form.minimo || 0) };
    const { data, error } = await supabase.from('estoque').insert(novo).select().single();
    if (error) { console.error('Erro ao inserir estoque:', error); return; }
    setEstoque([...estoque, data]);
    setForm({ nome: '', qtd: '', unidade: 'un', minimo: '' });
    setOpen(false);
  };

  const updateQtd = async (id: string, delta: number) => {
    const item = estoque.find((i) => i.id === id);
    if (!item) return;
    const novaQtd = Math.max(0, item.qtd + delta);
    const { error } = await supabase.from('estoque').update({ qtd: novaQtd }).eq('id', id);
    if (error) { console.error('Erro ao atualizar estoque:', error); return; }
    setEstoque(estoque.map((i) => (i.id === id ? { ...i, qtd: novaQtd } : i)));
  };

  const removeItem = async (id: string) => {
    const { error } = await supabase.from('estoque').delete().eq('id', id);
    if (error) { console.error('Erro ao remover estoque:', error); return; }
    setEstoque(estoque.filter((i) => i.id !== id));
  };

  return (
    <div>
      <div className="flex justify-between items-end">
        <SectionTitle subtitle="Controle os itens e receba alerta quando estiver acabando.">Estoque</SectionTitle>
        <PrimaryBtn onClick={() => setOpen(true)}>Novo item</PrimaryBtn>
      </div>

      <div className="bg-white border border-card-border rounded-lg overflow-hidden">
        {estoque.length === 0 ? <EmptyState text="Nenhum item cadastrado ainda." /> : (
          <table className="w-full border-collapse">
            <thead>
              <tr><Th>Item</Th><Th>Quantidade</Th><Th>Mínimo</Th><Th></Th></tr>
            </thead>
            <tbody>
              {estoque.map((i) => {
                const baixo = i.qtd <= i.minimo;
                return (
                  <tr key={i.id}>
                    <Td className="font-semibold">
                      {i.nome}
                      {baixo && <AlertTriangle size={13} className="inline ml-1.5 align-middle" style={{ color: '#B33A3A' }} />}
                    </Td>
                    <Td>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQtd(i.id, -1)}
                          className="w-6 h-6 rounded border border-card-border bg-[#FCFAF4] cursor-pointer hover:bg-paper-line transition-colors"
                        >–</button>
                        <span className="font-mono min-w-[60px] text-center" style={{ color: baixo ? '#B33A3A' : '#20291F' }}>
                          {i.qtd} {i.unidade}
                        </span>
                        <button
                          onClick={() => updateQtd(i.id, 1)}
                          className="w-6 h-6 rounded border border-card-border bg-[#FCFAF4] cursor-pointer hover:bg-paper-line transition-colors"
                        >+</button>
                      </div>
                    </Td>
                    <Td className="text-[#8A8270]">{i.minimo} {i.unidade}</Td>
                    <Td>
                      <IconBtn onClick={() => removeItem(i.id)} color="#B33A3A"><Trash2 size={16} /></IconBtn>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {open && (
        <Modal title="Novo item de estoque" onClose={() => setOpen(false)}>
          <FieldLabel>Nome do item</FieldLabel>
          <input className={inputClass} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex: Arroz 5kg" />
          <div className="flex gap-2.5">
            <div className="flex-1">
              <FieldLabel>Quantidade atual</FieldLabel>
              <input className={inputClass} type="number" value={form.qtd} onChange={(e) => setForm({ ...form, qtd: e.target.value })} />
            </div>
            <div className="flex-1">
              <FieldLabel>Unidade</FieldLabel>
              <select className={inputClass} value={form.unidade} onChange={(e) => setForm({ ...form, unidade: e.target.value })}>
                <option value="un">un</option><option value="kg">kg</option><option value="g">g</option><option value="l">l</option><option value="ml">ml</option><option value="pct">pct</option>
              </select>
            </div>
          </div>
          <FieldLabel>Quantidade mínima (alerta)</FieldLabel>
          <input className={inputClass} type="number" value={form.minimo} onChange={(e) => setForm({ ...form, minimo: e.target.value })} />
          <div className="mt-5"><PrimaryBtn onClick={addItem}>Salvar item</PrimaryBtn></div>
        </Modal>
      )}
    </div>
  );
}
