import { useState } from 'react';
import { Trash2, Check, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { type ContaItem, CATEGORIAS_CONTA, todayISO, formatBRL, formatDatePt } from '../types';
import { SectionTitle, EmptyState, IconBtn, PrimaryBtn, Modal, FieldLabel, Th, Td, inputClass } from './ui';

interface ContasTabProps {
  contas: ContaItem[];
  setContas: (next: ContaItem[]) => void;
}

export default function ContasTab({ contas, setContas }: ContasTabProps) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ nome: '', categoria: 'agua', valor: '', vencimento: todayISO() });

  const ordenado = [...contas].sort((a, b) => (a.vencimento > b.vencimento ? 1 : -1));

  const addConta = async () => {
    if (!form.nome || form.valor === '') return;
    const novo = {
      nome: form.nome,
      categoria: form.categoria,
      valor: Number(form.valor),
      vencimento: form.vencimento,
      status: 'pendente' as const,
    };
    const { data, error } = await supabase.from('contas').insert(novo).select().single();
    if (error) { console.error('Erro ao inserir conta:', error); return; }
    setContas([...contas, data]);
    setForm({ nome: '', categoria: 'agua', valor: '', vencimento: todayISO() });
    setOpen(false);
  };

  const toggleStatus = async (id: string) => {
    const conta = contas.find((c) => c.id === id);
    if (!conta) return;
    const novoStatus = conta.status === 'pago' ? 'pendente' : 'pago';
    const { error } = await supabase.from('contas').update({ status: novoStatus }).eq('id', id);
    if (error) { console.error('Erro ao atualizar conta:', error); return; }
    setContas(contas.map((c) => (c.id === id ? { ...c, status: novoStatus } : c)));
  };

  const removeConta = async (id: string) => {
    const { error } = await supabase.from('contas').delete().eq('id', id);
    if (error) { console.error('Erro ao remover conta:', error); return; }
    setContas(contas.filter((c) => c.id !== id));
  };

  return (
    <div>
      <div className="flex justify-between items-end">
        <SectionTitle subtitle="Água, luz, fornecedores, aluguel e outras contas.">Contas a pagar</SectionTitle>
        <PrimaryBtn onClick={() => setOpen(true)}>Nova conta</PrimaryBtn>
      </div>

      <div className="bg-white border border-card-border rounded-lg overflow-hidden">
        {ordenado.length === 0 ? <EmptyState text="Nenhuma conta cadastrada." /> : (
          <table className="w-full border-collapse">
            <thead>
              <tr><Th>Vencimento</Th><Th>Conta</Th><Th>Categoria</Th><Th>Valor</Th><Th>Status</Th><Th></Th></tr>
            </thead>
            <tbody>
              {ordenado.map((c) => (
                <tr key={c.id} style={{ opacity: c.status === 'pago' ? 0.55 : 1 }}>
                  <Td className="font-mono text-[#8A8270]">{formatDatePt(c.vencimento)}</Td>
                  <Td className="font-semibold">{c.nome}</Td>
                  <Td className="text-[#8A8270]">{CATEGORIAS_CONTA.find((k) => k.id === c.categoria)?.label}</Td>
                  <Td className="font-mono">{formatBRL(c.valor)}</Td>
                  <Td>
                    <button onClick={() => toggleStatus(c.id)}
                      className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full border-none cursor-pointer transition-colors"
                      style={{
                        background: c.status === 'pago' ? '#E7F0EC' : '#F5E9C8',
                        color: c.status === 'pago' ? '#2F6F62' : '#8A6D1E',
                      }}>
                      {c.status === 'pago' ? <Check size={12} /> : <Clock size={12} />}
                      {c.status === 'pago' ? 'Pago' : 'Pendente'}
                    </button>
                  </Td>
                  <Td><IconBtn onClick={() => removeConta(c.id)} color="#B33A3A"><Trash2 size={16} /></IconBtn></Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {open && (
        <Modal title="Nova conta a pagar" onClose={() => setOpen(false)}>
          <FieldLabel>Nome</FieldLabel>
          <input className={inputClass} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex: Conta de luz - Enel" />
          <FieldLabel>Categoria</FieldLabel>
          <select className={inputClass} value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}>
            {CATEGORIAS_CONTA.map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
          </select>
          <div className="flex gap-2.5">
            <div className="flex-1">
              <FieldLabel>Valor (R$)</FieldLabel>
              <input className={inputClass} type="number" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} />
            </div>
            <div className="flex-1">
              <FieldLabel>Vencimento</FieldLabel>
              <input className={inputClass} type="date" value={form.vencimento} onChange={(e) => setForm({ ...form, vencimento: e.target.value })} />
            </div>
          </div>
          <div className="mt-5"><PrimaryBtn onClick={addConta}>Salvar conta</PrimaryBtn></div>
        </Modal>
      )}
    </div>
  );
}
